function demo_driver

%-------------------------------------------------------------------
% OBJECT.
%-------------------------------------------------------------------
% In this demo we test the approximation over extremal sets as
% Approximate Fekete Points, Discrete Leja Points or alternatively
% of the LS squares on some relevant examples as in the domains
% 1. 'leaves': hypersurface in which (x,y,z) are in C^3, so that
%              z^2-x^3-y^2=0 satisfying x^2+y^2 <= 1.
% 2. 'Viviani window'.
% We allow to vary degrees "NV" and functions "f_example" to be appro-
% ximated.
%-------------------------------------------------------------------


% degrees
NV=1:1:10; 

% options: 1: leaves, 2: Viviani window.
example=1;

% function examples
f_example=1:4;

% perform tests
[RE_afek,leb_afek,card_AM,dim_ps]=demo_extremal_sets(NV,'afek',example,...
    f_example);
[RE_leja,leb_leja,card_AM,dim_ps]=demo_extremal_sets(NV,'leja',example,...
    f_example);
[RE_LS,leb_LS,card_AM,dim_ps]=demo_extremal_sets(NV,'LS',example,...
    f_example);

fprintf('\n \n ');

clf;

for k=1:length(f_example)
    figure(k)
    semilogy(NV',RE_afek(:,k),NV',RE_leja(:,k),NV',RE_LS(:,k),...
        'LineWidth',2);
    hold on;
    legend('AFP','DLP','LS','Location','northeast');
    % title(['Function ',num2str(k)])
    hold off;
    fname = gcf;
    name_file=['figure_',num2str(example),'_',num2str(k),'.png'];
    exportgraphics(fname,name_file);
    fprintf('\n \t saving plots on file '); disp(name_file);
end



% plot Lebesgue constants
figure(k+1)
semilogy(NV,leb_afek,NV,leb_leja,NV,leb_LS,'LineWidth',2);
hold on;
legend('AFP','DLP','LS','Location','northwest');
% title('Lebesgue constant')
fname = gcf;
name_file=['figure_',num2str(example),'_leb.png'];
exportgraphics(fname,name_file);
fprintf('\n \t saving plots on file '); disp(name_file);
hold off;

fprintf('\n \n');
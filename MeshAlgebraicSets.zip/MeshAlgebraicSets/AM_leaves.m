

function [P,AM_2D]=AM_leaves(n)

j=1:4*n+2;
r=cos((2*j-1)*pi/(8*n+4));

m=1:4*n+2;

[R,M]=meshgrid(r,j);

R=R(:); M=M(:);

x=1+R.*cos(M*pi/(4*n+2));
y=R.*sin(M*pi/(4*n+2));
zP=sqrt(x.^3+y.^2);
zM=-zP;

PP=[x y zP];
PM=[x y zM];

P=[PP; PM];
AM_2D=[x y];

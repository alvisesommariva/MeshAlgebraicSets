
function [RE,leb,card_AM,dim_ps]=demo_extremal_sets(NV,pts_type,example,...
    f_example)

%-------------------------------------------------------------------
% OBJECT.
%-------------------------------------------------------------------
% In this demo we test the approximation over extremal sets as
% Approximate Fekete Points, Discrete Leja Points or alternatively
% of the LS squares on some relevant examples as in the domains
% 1. 'leaves': hypersurface in which (x,y,z) are in C^3, so that
%              z^2-x^3-y^2=0 satisfying x^2+y^2 <= 1.
% 2. 'Viviani window':
%-------------------------------------------------------------------

if nargin < 1, NV=2:2:16; end

% options: 'afek', 'leja','LS'
if nargin < 2, pts_type='LS'; end

% options: 1: leaves, 2: Viviani window.
if nargin < 3, example=1; end

if nargin < 4, f_example=1:12; end % difficult: 1, 3.

if example == 3
    dim=2; 
else 
    dim=3;
end

ntest=30;

% Define LS pointset and test pointset.
[~,P_test,ex_str]=define_pointsets(example,0,ntest);

for k=1:length(NV)
    n=NV(k);

    % Compute approximation error test pointset
    P_LS=define_pointsets(example,n,ntest);

    % Compute extremal set.
    [P_DS,w,jvec,dbox]=define_extremalset(pts_type,n,P_LS);

    % Computing exact dimension of polynomial space
    dim_ps{k}=dim_polyspace(example,n);

    % Computing Lebesgue constant.
    leb(k) = dLEB(n,P_DS,[],P_LS,jvec,dbox,'',dim_ps{k});

    % Cardinality AM
    switch example
        case 1
            card_teo(k)=2*(4*n+2)^2;
        case 2
            card_teo(k)=20*n;
    end

    card_AM(k)=size(P_LS,1);

    % Printing pointset statistics
    fprintf('\n \n \t * '); disp(ex_str);
    switch example
        case 1
            fprintf('\n \t * AFP');
        case 2
            fprintf('\n \t * DLP');
        case 3
            fprintf('\n \t * LS');
    end
    fprintf('\n \t * LS degree     : %-8g',n);
    if length(dim_ps{k}) > 0
    fprintf('\n \t * Dim Poly.Theo : %-8g',dim_ps{k});
    end
    fprintf('\n \t * Dim Poly.Num  : %-8g',length(w > 0));

    fprintf('\n \t * AM card       : %-8g',card_AM(k));
    fprintf('\n \t * AM card theory: %-8g',card_teo(k));
    fprintf('\n \t * Extr.Set card : %-8g',size(P_DS,1));
    fprintf('\n \t * Test Set card : %-8g',size(P_test,1));
    fprintf('\n \t * Lebesgue cons.: %-3.3g',leb(k));
    % Running experiments over functions.
    for j=1:length(f_example)

        % Define function
        [g,gs]=define_function(f_example(j),dim);


        switch size(P_DS,2)
            case 2
                % Function evaluation at LS pointset.
                g_DS=feval(g,P_DS(:,1),P_DS(:,2));

                % Function evaluation at LS pointset.
                g_test=feval(g,P_test(:,1),P_test(:,2));
            case 3
                % Function evaluation at LS pointset.
                g_DS=feval(g,P_DS(:,1),P_DS(:,2),P_DS(:,3));

                % Function evaluation at LS pointset.
                g_test=feval(g,P_test(:,1),P_test(:,2),P_test(:,3));
        end

        % Solving LS problem.
        [coeff,R,jvec,dbox] = dPOLYFIT(n,P_DS,w,g_DS);

        % Evaluate LS approximant at test points.
        p_test = dPOLYVAL(n,coeff,P_test,R,jvec,dbox);

        % Evaluating LS approximant relative L2 error at test points.
        RE(k,j)=norm(g_test-p_test)/(norm(g_test));

    end

end




function [P_LS,P_test,ex_str]=define_pointsets(example,n,ntest)

switch example
    case 1
        P_LS=AM_leaves(n);
        if nargout >1, P_test=AM_leaves(ntest); end
        ex_str='Leaves';
    case 2
        P_LS=AM_viviani_window(n);
        if nargout >1, P_test=AM_viviani_window(ntest); end
        ex_str='Viviani window';
    case 3
        P_LS=AM_ex4_6(n);
        if nargout >1, P_test=AM_ex4_6(ntest); end
        ex_str='Complex Hypersurface';
end




function dim_ps=dim_polyspace(example,n)

switch example
    case 1
        k=3; dim_ps=(1/6)*k*(k^2-3*k*n-6*k+3*n^2+12*n+11);
    case 2
        dim_ps=4*n;
    case 3
        dim_ps=[];
end






function [pts,weights,jvec,dbox]=define_extremalset(pts_type,n,X,...
    dbox,dimpoly,domain_structure)

if nargin < 4, dbox=[]; end
if nargin < 5, dimpoly=[]; end
if nargin < 6, domain_structure=[]; end

switch pts_type
    case 'afek'
        %% APPROXIMATE FEKETE INTERPOLATION POINTS
        [pts,jvec,dbox] = dAPPROXFEK(n,X,0,dbox,domain_structure,dimpoly);
        weights=ones(length(pts(:,1)),1);

    case 'leja'
        %% DISCRETE LEJA INTERPOLATION POINTS
        [pts,jvec,dbox] = dAPPROXFEK(n,X,1,dbox,domain_structure,dimpoly);
        weights=ones(length(pts(:,1)),1);

    case 'LS'
        %% STANDARD LEAST SQUARES
        pts=X;
        weights=ones(length(X(:,1)),1);
        jvec=[];
        dbox=[];


    otherwise
        warning('Pointset not implemented, using Approx. Fekete points');
        %% APPROXIMATE FEKETE INTERPOLATION POINTS
        [pts,jvec,dbox] = dAPPROXFEK(n,X,0,dbox,dimpoly);
        weights=ones(length(fek(:,1)),1);

end

if isempty(dbox)
    dbox=[];
    L=size(X,2);
    for k=1:L
        mx=min(X(:,k)); Mx=max(X(:,k)); dboxL=[mx; Mx]; dbox=[dbox dboxL];
    end
end




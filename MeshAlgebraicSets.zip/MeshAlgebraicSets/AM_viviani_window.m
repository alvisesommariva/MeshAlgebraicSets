function P=AM_viviani_window(n)

j=1:5*n; j=j';
x=1+cos((2*j-1)*pi/(10*n));
yP=sqrt(2*x-x.^2);
zP=sqrt(4-x.^2-yP.^2);

P=[x yP zP; x yP -zP; x -yP zP; x -yP -zP];
function [f,fs]=define_function(example,dim)

if nargin < 2, dim=3; end

if dim == 2
    switch example
        case 1
            f=@(x,y) (x+0.5*y+1).^14;
            fs='(x+0.5*y-2*z+1).^14';
        case 2
            f=@(x,y) exp(-(x.^2+0.5*y.^2));
            fs='exp(-(x.^2+0.5*y.^2+2*z.^2))';
        case 3
            f=@(x,y) (sin(4*x+5*y));
            fs='sin(4*x+5*y+3*z)';
        case 4
            % x0=1; y0=0; z0=1;
            x0=0; y0=0.3;
            f=@(x,y) ((abs(x-x0)).^2+(abs(y-y0)).^2).^(1/2)+...
                ((abs(x-x0)).^2+(abs(y-y0)).^2).^(1/2);
            fs='Distances from two points';
        case 5
            % x0=1; y0=0; z0=1;
            x0=0; y0=0.3;
            f=@(x,y) (abs(x-x0)).^2+(abs(y-y0)).^(1);
            fs='Distances from one point';
        case 6
            f=@(x,y) (sin(x+2*y));
            fs='(sin(1*x+2*y))';
        case 7
            f=@(x,y) cos(exp(x+y)+0.1);
            fs='cos(exp(x+y)+0.1)';
    end
end



if dim == 3
    switch example
        case 1
            f=@(x,y,z) (x+0.5*y-2*z+1).^14;
            fs='(x+0.5*y-2*z+1).^14';
        case 2
            f=@(x,y,z) exp(-(x.^2+0.5*y.^2+2*z.^2));
            fs='exp(-(x.^2+0.5*y.^2+2*z.^2))';
        case 3
            f=@(x,y,z) (sin(4*x+5*y+3*z));
            fs='sin(4*x+5*y+3*z)';
        case 4
            % x0=1; y0=0; z0=1;
            x0=0; y0=0; z0=2;
            f=@(x,y,z) ((x-x0).^2+(y-y0).^2+(z-z0).^2).^(1/2)+...
                ((x-x0).^2+(y-y0).^2+(z+z0).^2).^(1/2);
            fs='Distances from two points';
    end
end
